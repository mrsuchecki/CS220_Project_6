export class FluentBusinesses {
    data;
    constructor(data) {
        this.data = data;
    }
    dataFilter(f) {
        const dataFiltered = this.data.filter(f);
        return new FluentBusinesses(dataFiltered);
    }
    getData() {
        return this.data;
    }
    fromCityInState(city, state) {
        const f = b => b.city === city && b.state === state;
        return this.dataFilter(f);
    }
    hasStarsGeq(stars) {
        const f = b => b.stars !== undefined && b.stars >= stars;
        return this.dataFilter(f);
    }
    inCategory(category) {
        const f = b => b.categories !== undefined && b.categories.includes(category);
        return this.dataFilter(f);
    }
    hasHoursOnDays(days) {
        const f = b => days.every(day => b.hours && b.hours[day] && b.hours[day].length > 0);
        return this.dataFilter(f);
    }
    hasAmbience(ambience) {
        const f = b => b.attributes !== undefined && b.attributes.Ambience?.[ambience] === true;
        return this.dataFilter(f);
    }
    bestPlace() {
        const dataSort = this.data.sort((b1, b2) => {
            if (b1.stars !== undefined &&
                b2.stars !== undefined &&
                b1.review_count !== undefined &&
                b2.review_count !== undefined) {
                if (b1.stars === b2.stars) {
                    if (b1.review_count === b2.review_count) {
                        return 0;
                    }
                    return b1.review_count > b2.review_count ? -1 : 1;
                }
                return b1.stars > b2.stars ? -1 : 1;
            }
            return 0;
        });
        return dataSort[0] || undefined;
    }
    mostReviews() {
        const dataSort = this.data.sort((b1, b2) => {
            if (b1.stars !== undefined &&
                b2.stars !== undefined &&
                b1.review_count !== undefined &&
                b2.review_count !== undefined) {
                if (b1.review_count === b2.review_count) {
                    return b1.stars > b2.stars ? -1 : 1;
                }
                return b1.review_count > b2.review_count ? -1 : 1;
            }
            return 0;
        });
        return dataSort[0] || undefined;
    }
}
//# sourceMappingURL=FluentBusinesses.js.map